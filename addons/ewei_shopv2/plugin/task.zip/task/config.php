<?php
if (!(defined('IN_IA'))) 
{
	exit('Access Denied');
}
return array('version' => '1.0', 'id' => 'task', 'name' => '任务系统');
?>